(()=>{'use strict';
const allowed={subject:new Set(['txtPositiveNegative','txtParcelNumber','txtTaxAssessedValue','txtTaxAssessedDate','txtLandValue','txtPropertyTax','txtLastSaleDate','txtLastSalePrice','ddlOwnershipType','ddlStyleType','txtCounty','txtMarketTimes','txtListingPriceLow','txtListingPriceHigh','ddlPropertyValues','txtNeighborhoodComments']),comparables:new Set(['txtZoningCode','txtAddress','txtCity','ddlState','txtZip','txtYearBuilt','txtRooms','txtBeds','txtSalePrice','txtCurrentListPrice','txtSaleDate','ddlView','ddlConditionType','ddlGarageType','ddlStyle','ddlDataSource','txtLotSizeAcres','txtMLSNumber','txtFullBaths','txtHalfBaths','txtGarages','txtSqFtLiving','txtBasementSqFt','txtDOM','ddlPropertyType','lbAmenities_0','txtConcessionsAmount','txtListPrice','txtOrigListDate','ddlSaleType','ddlFinancingType','txtNoUnits','ddlPoolSpa','ddlPositiveNegativeSign','txtAdjustment','chkBestSaleList'])};
const remarkPrefixes={txtSale1PropertyDataComments:'rrrSale1_',txtSale2PropertyDataComments:'rrrSale2_',txtSale3PropertyDataComments:'rrrSale3_',txtListing_1_PropertyDataComments:'rrrListing1_',txtListing_2_PropertyDataComments:'rrrListing2_',txtListing_3_PropertyDataComments:'rrrListing3_'};
function valid(f){if(!f||!['subject','comparables'].includes(f.section)||typeof f.value!=='string'||f.value.length>2000)return false;if(f.section==='subject')return allowed.subject.has(f.id);if(Object.hasOwn(remarkPrefixes,f.id))return true;const m=/^rrr(Subject|Sale[1-3]|Listing[1-3])_(.+)$/.exec(f.id);return !!m&&allowed.comparables.has(m[2])&&!(m[1]==='Subject'&&['txtAddress','txtCity','ddlState','txtZip','txtSalePrice','txtCurrentListPrice','txtListPrice','txtOrigListDate','ddlSaleType','ddlFinancingType','txtAdjustment','ddlPositiveNegativeSign','chkBestSaleList'].includes(m[2]));}
function validate(p){if(p?.format!=='propertythesis-rrr'||p.version!==1||p.client!=='rrr'||!Array.isArray(p.fields)||p.fields.length>400||!p.fields.every(valid)||new Set(p.fields.map(f=>f.section+f.id)).size!==p.fields.length)throw Error('Unsupported or invalid RRR transfer file.');if(!p.subject||['address','city','state','zip'].some(k=>typeof p.subject[k]!=='string'||!p.subject[k].trim()))throw Error('Missing subject identity.');}
const norm=s=>String(s||'').toUpperCase().replace(/\bSTREET\b/g,'ST').replace(/\bDRIVE\b/g,'DR').replace(/\bAVENUE\b/g,'AVE').replace(/\bROAD\b/g,'RD').replace(/[^A-Z0-9]/g,'');
function identity(doc){return {address:doc.getElementById('rrrSubject_txtAddress')?.value,city:doc.getElementById('rrrSubject_txtCity')?.value,state:doc.getElementById('rrrSubject_ddlState')?.value,zip:doc.getElementById('rrrSubject_txtZip')?.value};}
function identityPart(subject,key){
 const value=subject?.[key];
 if(key==='zip'){
  const zip=/^([0-9]{5})(?:-[0-9]{4})?$/.exec(String(value||'').trim());
  return zip?zip[1]:'';
 }
 if(key==='city' && /^(?:st[.]?|saint)\s+petersburg$/i.test(String(value||'').trim()))return 'STPETERSBURG';
 return norm(value);
}
function matches(a,b){
 return ['address','city','state','zip'].every(key=>{
  const value=identityPart(a,key);
  return Boolean(value)&&value===identityPart(b,key);
 });
}
const current=e=>e.type==='radio'||e.type==='checkbox'?String(e.checked):String(e.value||'');
function equivalent(e,value){
 const actual=current(e);
 if(e.id==='txtParcelNumber')return actual.replace(/[^a-z0-9]/gi,'')===String(value).replace(/[^a-z0-9]/gi,'');
 if(e.tagName==='SELECT')return e.selectedOptions[0]?.text===value;
 if(/_(txtSalePrice|txtCurrentListPrice|txtAdjustment|txtLotSizeAcres|txtYearBuilt|txtRooms|txtBeds|txtFullBaths|txtHalfBaths|txtGarages|txtSqFtLiving|txtBasementSqFt|txtDOM|txtConcessionsAmount|txtListPrice|txtNoUnits)$/.test(e.id)||/^(txtListingPriceLow|txtListingPriceHigh|txtTaxAssessedValue|txtLandValue|txtPropertyTax|txtLastSalePrice)$/.test(e.id)){
  const a=actual.replace(/[$,]/g,'').trim(),b=String(value).replace(/[$,]/g,'').trim();
  if(a&&b&&Number.isFinite(Number(a))&&Number.isFinite(Number(b)))return Number(a)===Number(b);
 }
 return actual===value;
}
function concessionsCompatible(doc,p,prefix){const actual=Number(String(doc.getElementById(prefix+'txtConcessionsAmount')?.value||'0').replace(/[$,]/g,''));const proposed=p.fields.find(f=>f.id===prefix+'txtConcessionsAmount');return actual===0||(proposed&&Number(proposed.value)===actual);}
// RRR initializes these editable property facts to zero on new orders.
// Keep zero adjustments, prices, concessions and unrelated fields protected.
function propertyZero(e,value){return /^rrr(?:Subject|Sale[1-3]|Listing[1-3])_txt(?:YearBuilt|Rooms|Beds|FullBaths|HalfBaths|SqFtLiving|Garages|LotSizeAcres)$/.test(e.id)&&/^0(?:\.0+)?$/.test(current(e).trim())&&Number.isFinite(Number(value))&&Number(value)>0;}
function plan(doc,p,section,overwrite=false){validate(p);const rows=p.fields.filter(f=>f.section===section).map(f=>{if(/_txtLotSizeAcres$/.test(f.id)&&f.value.trim()&&Number.isFinite(Number(f.value)))f={...f,value:String(Math.round((Number(f.value)+Number.EPSILON)*100)/100)};const e=doc.getElementById(f.id),row={...f,before:e?current(e):'',status:'ready'};if(!e)row.status='not present';else if(e.disabled||e.readOnly)row.status='locked';else if(!e.getClientRects().length)row.status='not visible';else if(!['INPUT','SELECT','TEXTAREA'].includes(e.tagName))row.status='unsupported';else if(e.tagName==='SELECT'&&![...e.options].some(o=>o.text===f.value&&!o.disabled))row.status='unmatched choice';else if(e.maxLength>0&&f.value.length>e.maxLength)row.status='too long';else if(equivalent(e,f.value))row.status='already matches';else if(propertyZero(e,f.value)||(/^(txtTaxAssessedValue|txtLandValue|txtPropertyTax|txtLastSalePrice)$/.test(e.id)&&Number(row.before.replace(/[$,]/g,''))===0&&Number(f.value)>0)||(/_txtNoUnits$/.test(e.id)&&Number(row.before)===0&&f.value==='1')||(/_txtListPrice$/.test(e.id)&&Number(row.before.replace(/[$,]/g,''))===0&&Number(f.value)>0))row.status='ready';else if((e.tagName==='SELECT'?String(e.selectedOptions[0]?.text||'').trim():e.type==='checkbox'?e.checked:row.before.trim())&&!overwrite)row.status='existing entry — preserved';return row;});
 for(const prefix of [...new Set(rows.filter(r=>r.section==='comparables'&&/^rrr(?:Sale|Listing)[1-3]_/.test(r.id)).map(r=>r.id.split('_')[0]+'_'))]){const address=rows.find(r=>r.id===prefix+'txtAddress'),price=rows.find(r=>r.id===prefix+(prefix.startsWith('rrrSale')?'txtSalePrice':'txtCurrentListPrice')),sign=rows.find(r=>r.id===prefix+'ddlPositiveNegativeSign'),amount=rows.find(r=>r.id===prefix+'txtAdjustment'),ok=r=>r&&['ready','already matches'].includes(r.status);if(!ok(address))for(const r of rows.filter(r=>r.id.startsWith(prefix)&&r.status==='ready'))r.status='comparable address conflict — skipped';if(sign&&amount&&amount.status==='ready'&&!amount.before.trim()&&sign.status==='existing entry — preserved')sign.status='ready';if(sign&&amount&&(!ok(sign)||!ok(amount)||!ok(price)||!concessionsCompatible(doc,p,prefix)))for(const r of [sign,amount])if(r.status==='ready')r.status='adjustment dependency — review manually';}
 for(const row of rows.filter(r=>Object.hasOwn(remarkPrefixes,r.id)&&r.status==='ready')){const address=rows.find(r=>r.id===remarkPrefixes[row.id]+'txtAddress');if(!address||!['ready','already matches'].includes(address.status))row.status='comparable address conflict - skipped';}
 return rows;}
function apply(doc,p,section,review,overwrite){const fresh=plan(doc,p,section,overwrite),out=[];for(const old of review.filter(r=>r.status==='ready')){const r=fresh.find(f=>f.id===old.id),e=doc.getElementById(old.id);if(!r||r.status!=='ready'||r.before!==old.before||r.value!==old.value||!e||!e.isConnected||e.disabled||e.readOnly||current(e)!==old.before){out.push({id:old.id,status:'changed since preview — skipped'});continue;}if(e.tagName==='SELECT')e.value=[...e.options].find(o=>o.text===r.value).value;else if(e.type==='radio'||e.type==='checkbox')e.checked=r.value==='true';else e.value=r.value;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));e.dispatchEvent(new Event('blur',{bubbles:true}));out.push({id:r.id,status:doc.getElementById(r.id)===e&&equivalent(e,r.value)?'filled':'verify in RRR'});}return out;}
globalThis.PTRRR={validate,identity,matches,plan,apply};})();
